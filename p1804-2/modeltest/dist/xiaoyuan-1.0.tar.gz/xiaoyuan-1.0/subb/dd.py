def d():
    print('ddd')
