def c():
    print('ccc')
