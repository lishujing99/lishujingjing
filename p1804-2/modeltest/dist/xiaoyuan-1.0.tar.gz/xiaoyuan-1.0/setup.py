from distutils.core import setup
setup(name='xiaoyuan',version='1.0',description='xiaoyuan is module',author='xiaoyuan',py_modules=['suba.aa','suba.bb','subb.cc','subb.dd'])
