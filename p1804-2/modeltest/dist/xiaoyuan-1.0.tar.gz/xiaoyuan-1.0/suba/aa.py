def a():
    print('aaa')
