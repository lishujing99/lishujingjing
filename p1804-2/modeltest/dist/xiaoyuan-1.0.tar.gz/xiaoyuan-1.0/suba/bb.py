def b():
    print('bbb')
